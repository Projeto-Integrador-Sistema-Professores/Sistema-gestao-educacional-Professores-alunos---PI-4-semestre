// lib/src/ui/grade_launch_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/courses_provider.dart';
import 'package:go_router/go_router.dart';
import '../models/assignment.dart';

class GradeLaunchPage extends ConsumerStatefulWidget {
  final String courseId;
  final String studentId;
  final String? assignmentId; // optional initial assignment
  const GradeLaunchPage({
    required this.courseId,
    required this.studentId,
    this.assignmentId,
    super.key,
  });

  @override
  ConsumerState<GradeLaunchPage> createState() => _GradeLaunchPageState();
}

class _GradeLaunchPageState extends ConsumerState<GradeLaunchPage> {
  final _scoreCtrl = TextEditingController();
  bool loading = false;
  String? msg;
  String? _selectedAssignmentId;

  @override
  void initState() {
    super.initState();
    _selectedAssignmentId = widget.assignmentId;
  }

  @override
  void dispose() {
    _scoreCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final submitGrade = ref.read(submitGradeProvider);
    final courseDetailAsync = ref.watch(courseDetailProvider(widget.courseId));

    return Scaffold(
      appBar: AppBar(title: const Text('Lançar Nota')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: courseDetailAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, s) => Center(child: Text('Erro ao carregar curso: $e')),
          data: (courseData) {
            final assignmentsRaw = courseData['assignments'] as List<dynamic>? ?? [];
            // normalize to Assignment instances
            final assignments = assignmentsRaw.map((a) {
              if (a is Assignment) return a;
              if (a is Map<String, dynamic>) return Assignment.fromJson(Map<String, dynamic>.from(a));
              try {
                return Assignment.fromJson(Map<String, dynamic>.from(a as Map));
              } catch (_) {
                return Assignment(
                  id: '${DateTime.now().millisecondsSinceEpoch}',
                  title: a?.toString() ?? 'Atividade',
                  description: '',
                  dueDate: DateTime.now(),
                  weight: 1.0,
                );
              }
            }).toList();

            // if no selected assignment, set default to first if exists
            if (_selectedAssignmentId == null && assignments.isNotEmpty) {
              _selectedAssignmentId = assignments.first.id;
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Aluno ID: ${widget.studentId}', style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 12),
                const Text('Escolha a atividade:', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _selectedAssignmentId,
                  items: assignments.map((a) {
                    return DropdownMenuItem(
                      value: a.id,
                      child: Text('${a.title} (${a.dueDate.day}/${a.dueDate.month}/${a.dueDate.year})'),
                    );
                  }).toList(),
                  onChanged: (v) => setState(() => _selectedAssignmentId = v),
                  decoration: const InputDecoration(border: OutlineInputBorder()),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _scoreCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'Nota (0.0 - 10.0)', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  ElevatedButton.icon(
                    icon: loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save),
                    label: const Text('Lançar'),
                    onPressed: loading
                        ? null
                        : () async {
                            final val = double.tryParse(_scoreCtrl.text.replaceAll(',', '.'));
                            if (val == null || val < 0 || val > 10) {
                              setState(() {
                                msg = 'Insira uma nota válida entre 0 e 10.';
                              });
                              return;
                            }
                            if (_selectedAssignmentId == null) {
                              setState(() {
                                msg = 'Selecione uma atividade.';
                              });
                              return;
                            }

                            setState(() {
                              loading = true;
                              msg = null;
                            });

                            try {
                              await submitGrade(widget.courseId, widget.studentId, _selectedAssignmentId!, val);
                              setState(() {
                                msg = 'Nota lançada com sucesso!';
                              });
                              // optional: refresh course detail provider so UI shows updated grades
                              ref.refresh(courseDetailProvider(widget.courseId));
                              await Future.delayed(const Duration(milliseconds: 600));
                              if (context.mounted) context.pop();
                            } catch (e) {
                              setState(() {
                                msg = 'Erro ao lançar nota: $e';
                              });
                            } finally {
                              setState(() {
                                loading = false;
                              });
                            }
                          },
                  ),
                  const SizedBox(width: 12),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.refresh),
                    label: const Text('Recarregar atividades'),
                    onPressed: () {
                      // force refresh course details to get latest assignments
                      ref.refresh(courseDetailProvider(widget.courseId));
                    },
                  )
                ]),
                if (msg != null) ...[
                  const SizedBox(height: 12),
                  Text(msg!, style: const TextStyle(color: Colors.green)),
                ]
              ],
            );
          },
        ),
      ),
    );
  }
}
