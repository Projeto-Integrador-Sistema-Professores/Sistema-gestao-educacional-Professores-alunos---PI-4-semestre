const bool useFakeApi = true; // set to false to use real backend
const String apiBaseUrl = 'https://api.sistema.local/v1'; // altere quando tiver backend
